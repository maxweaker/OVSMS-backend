create
    definer = root@localhost procedure regist(IN cName varchar(64), IN cPassword varchar(64), IN cAge int,
                                              IN cStartLine varchar(64))
begin
    if exists(select * from User where name = uname) then
        select 'This name has been taken';
    else
        insert into user values (cName,cPassword,cAge,cStartLine);
    end if;
end;

