create
    definer = root@localhost procedure login(IN cName varchar(64), IN cPassword varchar(64))
begin
    if not exists(select * from man_management_customer where name = cName) then
        select 'This name not exists';
    else
        if not exists(select * from man_management_customer where name = cName and password = cPassword) then
            select 'wrong password';
        else
            select 'login successfully';
        end if;
    end if;
end;

