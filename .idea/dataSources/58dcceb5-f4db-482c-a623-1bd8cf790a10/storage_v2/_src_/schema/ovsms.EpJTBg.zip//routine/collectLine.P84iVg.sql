create
    definer = root@localhost procedure collectLine(IN cusID int, IN lineID int)
begin
    if exists(select * from traffic_control_line where id = lineID) then
        update man_management_customer set startLine_id = lineID where id = cusID;
    else
        select 'this line not exists';
    end if;
end;

