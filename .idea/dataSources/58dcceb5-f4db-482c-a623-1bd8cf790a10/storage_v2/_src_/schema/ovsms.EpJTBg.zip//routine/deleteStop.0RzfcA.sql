create
    definer = root@localhost procedure deleteStop(IN sName varchar(255), IN lineID int)
begin
    declare sq int;
    select sequence from traffic_control_stop where stopName = sName and line_id = lineID into sq;
    if not exists(select * from traffic_control_stop where stopName = sName and line_id = lineID) then
        select 'no such a stop';
    else
        update traffic_control_stop set sequence = sequence-1
        where sequence> sq;
        delete from traffic_control_stop where stopName = sName and line_id = lineID;
    end if;
end;

